import React from 'react';
// import logo from './logo.svg';
import './App.css';
import AppUi from './AppUi'

function App() {
  return (
    <div className="App">
      <AppUi/>
    </div>
  );
}

export default App;
