import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';



class AppUi extends React.Component{
    handleClick() {
        console.log("Hi from function");
      }
      handleChange(event) {
        // console.log("Hi from Change");
        event.preventDefault();
        let amount=event.target.value;
        let noOfNotes=0;
        let moneyLeft=0;
        
        let denominations=[2000,500,200,100,50,20,10,5,2,1];
        
        for(let noteNum=0;noteNum<denominations.length;noteNum++){
            let biggestNote=Math.max(...denominations);
            let totalNotes=0;
                noOfNotes=Math.floor(amount/biggestNote);
                totalNotes = totalNotes+noOfNotes;
                moneyLeft=amount%biggestNote;
                amount=moneyLeft
                denominations.shift();//shift()              
                console.log(`Number of notes ${totalNotes} & moneyleft is ${moneyLeft}`);
        // } console.log(`Number of notes ${totalNotes} & moneyleft is ${moneyLeft}`);
            }}
            
    render(){
        return <>
        <header className="App"style={{backgroundColor: "#4b0082"}}>
            <br/>
            <h1 className="text-white">ATM Money Dispenser</h1>
            <br/>
        </header>
        <div className="container-fluid">
        <div className="row bg-secondary">
    <div className="col card ">
      <form className="card-body h-75">
          <h2>Welcome to ATM Money Dispenser</h2>
          <label htmlFor="amount">Enter the Amount To Be Dispensed</label><br/>
          <input type="number" id="amount" onChange={this.handleChange} placeholder="0"/><br/><br/>
          <button type="button" className="btn btn-primary block" onClick={this.handleClick}>Get Money</button>
      </form>
    </div>
    <div className="col">
      You will get following amount:

    </div>
    </div>
        </div>
        </>
    }
}


export default AppUi;